# Till — UI Interaction Logic

Android income/spend tracker for small business owners. Single Design Component: `Till.dc.html` (logic in its `Component` class, rendered inside `android-frame.jsx`).

## Layout shell

- Header (fixed top): app name "Till" + gear icon button (top right) → opens **Settings** subpage. Below it, the current tab's title (`h3`) and the business name.
- Content area: scrollable, shows one of 4 tabs based on `state.tab` (0=Transactions, 1=Stock, 2=Reports, 3=Todo).
- Bottom nav bar: 4 buttons evenly split around a centered floating action button (FAB).
  - Left pair: Transactions, Todo
  - Right pair: Reports, Stock
  - Center FAB (raised circle, `+` icon): opens the **Add transaction** sheet.
- Two full-screen overlays (`showSettings`, `showDetail`) and two dialogs (`showAddStock`, `showStockConfirm`) render on top of everything (`z-index` 2–3), each with a back/cancel action that returns to the underlying tab.

## Tabs

### 0 — Transactions (default)
- Top card: account balance (static `$8,942.10`) + this-month net change tag.
- Segmented filter: All / Income / Spend — filters `txns` by `type`.
- Transaction list grouped by date. Each row: colored initial avatar, name, category · time · payment method · paid mark (✔/✖), amount (green if income).
- **Tapping a row** opens the **Edit transaction** detail page (`state.detailItem`), pre-filled with amount, description, category, payment method, paid status, remarks. Created/modified timestamps are read-only. Category is chip-based: click a chip to select it, click its ✕ to delete it, or use "+ New" to add a custom category inline. Cancel/Save both close the page (no-op save — see Known limitations).

### 1 — Stock
- Header row: low-stock count ("N low") + "Add item" button → opens **Add stock item** sheet (name, starting quantity, unit; supports decimal quantities).
- Each stock card: item name, trash icon (removes the item immediately, no confirmation), "Low" tag if qty ≤ its low threshold, quantity (large bold number) + editable unit text box, and a −/+ row with a numeric **amount box** in the middle (defaults to 1, accepts decimals) that sets how much −/+ changes.
- Clicking **−** or **+** does NOT change the value directly — it opens the **stock confirmation dialog** showing "Increase/Decrease stock?" with the computed message and new total. Confirm applies the change; Cancel/backdrop click discards it.

### 2 — Reports
- Three stat cards: Income / Spend / Net for the month (static labels).
- "Spend by category" bar list, sourced from the same `budgets` data used for the old Budgets tab (kept internally for this chart only — there is no user-facing Budgets tab anymore).
- "Last 7 days · net cash flow" — 7 bars sized by `week` data, gray for negative days.

### 3 — Todo
- Card list of tasks (title, description, Mark done / ✔ Done button).
- **Sort rule:** undone tasks always render first (in their original order); once marked done, a task moves to the end of the list, after all undone tasks. Toggling back to undone returns it to the undone group (still appended after other undone tasks, since original index ordering only matters within each group).

## Global overlays

### Settings (gear icon)
Back arrow returns to whichever tab was active.
- Business name (text input)
- Currency (select: USD/EUR/GBP/CAD — cosmetic only, not yet wired to amount formatting)
- Language (select: English / 简体中文) — see Localization below
- Data: **Export** downloads a `till-data.json` snapshot (business name, currency, transactions, stock, todos, budgets). **Import** opens a file picker; loading a valid JSON replaces stock/todos/business name/currency and shows a status message.
- No sign-in/sign-out, no notification toggle (explicitly removed), no low-stock-alert toggle (explicitly removed).

### Add transaction (FAB)
Bottom sheet: Spend/Income segmented toggle, amount, description, category select, date. Cancel/Save both close the sheet (no-op save).

### Add stock item
Bottom sheet opened from the Stock tab: name, starting quantity (decimal-friendly), unit. Save pushes a new row into the stock list; low threshold auto-computed as 20% of starting quantity.

### Stock change confirmation
Centered modal, always shown before a −/+ stock edit is applied. Shows verb (Increase/Decrease), item name, delta, unit, and resulting new total. Confirm commits; Cancel/backdrop discards.

## Localization

`state.settingsLanguage` (`'en'` default, or `'zh-CN'`) selects a translation table (`this.i18n.en` / `this.i18n['zh-CN']`) built in the logic class. All **UI chrome** — tab titles, nav labels, buttons, field labels, dialog copy, placeholders, stock-confirmation message, import status text — is looked up through this table via a per-render `L` object exposed as `{{ L.someKey }}` in the template. **User content** (sample transaction names, category names, todo text) is not translated — it's data, not UI.

## State model (high level)

- `tab`: 0–3, which tab is active.
- `stock`, `todos`: null until first edit, then a full copy of the respective array (edits are copy-on-write against `this.stock`/`this.todos` defaults).
- `stockAmounts`: map of row index → current custom amount string for that row's −/+ box.
- `stockConfirm`: pending stock change `{index, delta, verb, name, unit, newQty}` or `null`.
- `showAddStock`, `newStockName/Qty/Unit`: Add-stock-item sheet state.
- `showSettings`, `settingsName/Currency/Language`, `importMessage`: Settings subpage state.
- `detailItem`, `detailCategory`, `detailMethod`, `detailPaid`: Edit-transaction detail page state (pre-filled from the tapped row).
- `categories`, `addingCategory`, `newCategoryName`: the editable category-chip list shared by the detail page.
- `filter`: Transactions tab segmented filter (`all`/`income`/`spend`).
- `sheetType`: Add-transaction sheet's Income/Spend toggle.

## Known limitations (mockup, not a real backend)

- All data is static sample data (`this.txns`, `this.budgets`, `this.week`) except stock and todos, which are mutable in component state.
- "Save" in Add transaction and Edit transaction closes the panel without persisting new values — those forms are visual/interactive but not wired to update `txns`.
- Export/Import round-trips stock, todos, business name and currency only — not transactions or budgets.
- Currency selector doesn't reformat displayed amounts (still hardcoded `$`).
- No real authentication — the Settings page has no sign-in/out by design.
